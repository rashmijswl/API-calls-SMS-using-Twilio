from flask import Flask, render_template
import os
from twilio.rest import Client
import urllib.request
import json
import random as r
#Harry Potter API

harry_url = 'http://hp-api.herokuapp.com/api/characters'
harry_request = urllib.request.urlopen(harry_url)
harry_result = json.loads(harry_request.read())
rand_char = r.randint(0,len(harry_result))

character = harry_result[rand_char]['name']) # getting random characters name

api = "31f11bc73507f9b64497055e3a37b063"
city = "secunderabad"

#OpenWeather API

weather_url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api}"

weather_request = urllib.request.urlopen(weather_url)
weather_result = json.loads(weather_request.read()) 

#print(result['main']['temp'])
celsius_temp = weather_result["main"]["temp"] - 273.15 #converting F to C


#OpenNotify api

space_url = 'http://api.open-notify.org/astros.json'

space_request = urllib.request.urlopen(space_url)
space_result = json.loads(space_request.read())

space_people = space_result['number']

#message draft 

msg = f"Harry Potter Charecter, {character.title()} says weather in {city.title} is  {celsius_temp} degree celcius and there are {space_people} in the space"

app = Flask(__name__)


# Find your Account SID and Auth Token at twilio.com/console
# and set the environment variables. See http://twil.io/secure
auth_token = os.environ['Auth Token']
account_sid = os.environ['Account SID']
client = Client(account_sid, auth_token)



@app.route('/')
def hello_world():
  return render_template("index.html")

@app.route('/sms')
def send_sms():
    #this is where you connect to the APIs and send the sms
    message = client.messages \
                  .create(
                       body=msg,
                       from_='+19807341526',
                       to='+16479165977'
                   )
    return render_template("success.html")

app.run(host='0.0.0.0', port=8080)